create database Employee_details
use Employee_details


create table employee
(
Id int primary key identity,
Employee_name varchar(100),
Designation varchar(100),
Salary money,
Email varchar(100),
Mobile bigint,
Qualification varchar(100),
Manager varchar(100)
)


sp_help employee
select * from employee

create proc sp_tbl_employee
(
@action varchar(100)=null,
@Id int=0,
@Employee_name varchar(100)=null,
@Designation varchar(100)=null,
@Salary money=0,
@Email varchar(100)=null,
@Mobile bigint=0,
@Qualification varchar(100)=null,
@Manager varchar(100)=null
)
as
begin
if (@action='INSERT')
begin
insert into employee(Employee_name,Designation,Salary,Email,Mobile,Qualification,Manager)
values(@Employee_name,@Designation,@Salary,@Email,@Mobile,@Qualification,@Manager)
end
else if(@action='SELECT')
begin
select * from employee
end
else if(@action='DELETE')
begin
delete from employee where id = @Id
end
else if(@action='EDIT')
begin
select * from employee where id = @Id
end
else if(@action='UPDATE')
begin
update employee set Employee_name=@Employee_name,
Designation=@Designation,Salary=@Salary,Email=@Email,Mobile=@Mobile,Qualification=@Qualification,Manager=@Manager
where id = @Id
end
end
select * from employee



select * from employee